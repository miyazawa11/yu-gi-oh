from __future__ import annotations

import re
import hashlib
import shutil
import subprocess
import time
from pathlib import Path
from typing import Protocol

import cv2

from .image_io import read_image, write_image
import numpy as np

from .capture import Frame
from .cards import CardDatabase
from .models import Action, ActionType, CardIdentity, GameState, Observation, Phase, Player, PlayerState
from .regions import Calibration, Region


class NumericOCR(Protocol):
    def read(self, crop: np.ndarray, maximum: int) -> tuple[int | None, float]: ...


class TesseractOCR:
    def __init__(self, command: str = "tesseract"):
        self.command = shutil.which(command)

    def read(self, crop: np.ndarray, maximum: int, *, deadline: float | None = None) -> tuple[int | None, float]:
        if self.command is None:
            return None, 0
        gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
        # 大きな滑らかな数字の拡大により5200を9200と誤認した回帰を防ぎます。
        # 小さな画像だけ拡大し、2種類の前処理の一致を求めます。
        if gray.shape[0] < 40:
            scale = 40/gray.shape[0]
            gray = cv2.resize(gray, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
        _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
        # 数字の形を保ち、余白の多い数値画像は白背景にして OCR を助けます。
        if np.mean(binary) < 127:
            binary = 255 - binary
            gray = 255 - gray
        predictions = []
        for rendering in [gray, binary]:
            rendering = cv2.copyMakeBorder(rendering, 12, 12, 12, 12, cv2.BORDER_CONSTANT, value=255)
            predictions.append(self._read_rendering(rendering, maximum, deadline=deadline))
        if predictions[0][0] is None or predictions[0][0] != predictions[1][0]:
            return None, 0
        return predictions[0][0], min(predictions[0][1], predictions[1][1])

    def _read_rendering(self, rendering: np.ndarray, maximum: int, *, deadline: float | None = None) -> tuple[int | None, float]:
        ok, png = cv2.imencode(".png", rendering)
        if not ok:
            return None, 0
        remaining = 3 if deadline is None else min(3, deadline - time.monotonic())
        if remaining <= 0:
            raise TimeoutError("認識・判断の期限に達しました")
        try:
            result = subprocess.run([self.command, "stdin", "stdout", "--psm", "7", "-c", "tessedit_char_whitelist=0123456789", "tsv"], input=png.tobytes(), capture_output=True, timeout=remaining, check=True)
        except (subprocess.SubprocessError, OSError):
            return None, 0
        tokens, confidences = [], []
        for line in result.stdout.decode("utf-8", errors="replace").splitlines()[1:]:
            fields = line.split("\t")
            if len(fields) == 12 and fields[0] == "5" and fields[11].strip():
                tokens.append(fields[11].strip())
                try:
                    confidences.append(max(0, min(1, float(fields[10])/100)))
                except ValueError:
                    return None, 0
        if len(tokens) != 1 or not re.fullmatch(r"\d{1,6}", tokens[0]):
            return None, 0
        value = int(tokens[0])
        confidence = min(confidences, default=0)
        if value > maximum or confidence < 0.9:
            return None, 0
        return value, confidence


def fingerprint(pixels: np.ndarray) -> np.ndarray:
    """色を保つ正規化画像の特徴量です。学習済み埋め込みではありません。"""
    return cv2.resize(pixels, (64, 32), interpolation=cv2.INTER_AREA).astype(np.float32)/255


class TemplateMatcher:
    def __init__(self, region: Region, base: Path, allowed_card_ids: set[str] | None = None):
        self.region = region
        self.templates: list[tuple[str, np.ndarray]] = []
        self.asset_hashes = {}
        self.stable_profiles = []
        self.stable_statistics = {}
        for exemplar in region.exemplars:
            if region.kind == "card" and allowed_card_ids is not None and exemplar.label not in allowed_card_ids:
                continue
            path = (base/exemplar.image).resolve()
            # 校正用のローカル画像が指定フォルダーの外を参照するのを防ぎます。
            if not path.is_relative_to(base.resolve()):
                raise ValueError("参照画像は校正ファイルのフォルダー内に配置してください")
            image = read_image(str(path))
            if image is None:
                raise ValueError(f"参照画像を読み込めません: {path}")
            self.asset_hashes[path.relative_to(base.resolve()).as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
            self.templates.append((exemplar.label, fingerprint(image)))
        if region.kind in {"template", "card", "action"} and not region.exemplars:
            raise ValueError("テンプレート領域には参照画像が必要です")

        if region.feature == "stable_rgb":
            for label in sorted({label for label, _ in self.templates}):
                samples = [feature for key, feature in self.templates if key == label]
                if len(samples) < 10:
                    raise ValueError("stable_rgbはラベルごとに10枚以上の時間変動訓練画像が必要です")
                stack = np.stack(samples)
                prototype = np.median(stack, axis=0)
                deviation = np.max(np.mean(np.abs(stack-prototype), axis=3), axis=0)
                mask = deviation <= .01
                count = int(np.count_nonzero(mask))
                if count < 256:
                    raise ValueError("stable_rgbの安定画素が256未満です。認識を開始できません")
                self.stable_profiles.append((label, prototype, mask))
                self.stable_statistics[label] = {"training_samples": len(samples), "valid_pixels": count,
                    "total_pixels": int(mask.size), "maximum_deviation": .01, "minimum_pixels": 256,
                    "mask_sha256": hashlib.sha256(mask.tobytes()).hexdigest(),
                    "prototype_sha256": hashlib.sha256(prototype.tobytes()).hexdigest()}

    def match(self, crop: np.ndarray) -> tuple[str | None, float]:
        descriptor = fingerprint(crop)
        scores: dict[str, float] = {}
        if self.region.feature == "rgb":
            for label, template in self.templates:
                score = float(1 - np.mean(np.abs(descriptor-template)))
                scores[label] = max(scores.get(label, 0), score)
        if self.region.feature == "stable_rgb":
            # mask外をゼロ埋めして全体平均しない。有効画素×RGB成分だけが分母。
            scores = {label: float(1-np.mean(np.abs(descriptor-prototype)[mask]))
                      for label, prototype, mask in self.stable_profiles}
        ranked = sorted(scores.items(), key=lambda entry: entry[1], reverse=True)
        if not ranked:
            return None, 0
        label, best = ranked[0]
        runner_up = ranked[1][1] if len(ranked) > 1 else 0
        if best < self.region.threshold or best-runner_up < self.region.margin:
            return None, 0
        return label, best


class Perception:
    def __init__(self, calibration: Calibration, base: Path, cards: CardDatabase, ocr: NumericOCR | None = None,
                 allowed_card_ids: set[str] | None = None):
        self.calibration, self.cards = calibration, cards
        self.ocr = ocr or TesseractOCR()
        self.matchers = {name: TemplateMatcher(region, base, allowed_card_ids) for name, region in calibration.regions.items() if region.kind in {"template", "card", "action"}}
        self.asset_hashes = {name: matcher.asset_hashes for name, matcher in self.matchers.items()}
        self.stable_statistics = {name: matcher.stable_statistics for name, matcher in self.matchers.items() if matcher.stable_statistics}
        self._validate_semantics()
        self._cache: dict[str, tuple[np.ndarray, object, float]] = {}
        self.cache_hits = 0
        self.recognized_regions = 0
        self.ocr_ms = self.state_build_ms = 0

    def _validate_semantics(self):
        numeric_names = {"self.lp", "opponent.lp", "self.hand_count", "opponent.hand_count", "turn"}
        for name, region in self.calibration.regions.items():
            labels = [e.label for e in region.exemplars]
            if region.kind == "unobserved":
                continue
            if name in numeric_names:
                if region.kind not in {"number", "template"}:
                    raise ValueError(f"数値項目に未対応の認識方式が指定されています: {name}")
                maximum = 999999 if name.endswith(".lp") else 999 if name == "turn" else 60
                if any(not label.isdecimal() or int(label) > maximum for label in labels):
                    raise ValueError(f"数値テンプレートのラベルが不正です: {name}")
            elif name == "phase":
                if region.kind != "template":
                    raise ValueError("フェイズ認識にはテンプレートが必要です")
                for label in labels:
                    Phase(label)
            elif name == "turn_player":
                if region.kind != "template":
                    raise ValueError("ターンプレイヤー認識にはテンプレートが必要です")
                for label in labels:
                    Player(label)
            elif name == "game.terminal":
                if region.kind != "template" or any(label not in {"ended", "active"} for label in labels):
                    raise ValueError("game.terminal には template と ended / active のラベルが必要です")
            elif name == "ui.prompt":
                if region.kind != "template" or any(not label for label in labels):
                    raise ValueError("ui.promptには空でない識別名のtemplateが必要です")
            elif name == "ui.animation":
                if region.kind != "template" or any(label not in {"playing", "idle"} for label in labels):
                    raise ValueError("ui.animationにはplaying/idleのtemplateが必要です")
            elif name.startswith("fact."):
                if region.kind != "template" or not labels or any(not label for label in labels):
                    raise ValueError("展開条件には空でない識別値のtemplateが必要です")
            elif name.startswith("card_state."):
                if region.kind != "template" or any(label not in {"face_up", "face_down", "selectable", "selected"} for label in labels):
                    raise ValueError("カード状態にはface_up/face_down/selectable/selectedのtemplateが必要です")
            elif name.startswith("action."):
                if region.kind != "action":
                    raise ValueError("操作項目には操作 UI のテンプレートが必要です")
                for label in labels:
                    ActionType(label)
            elif re.fullmatch(r"(self|opponent)\.zones\.[a-zA-Z0-9_]+", name):
                if region.kind != "card":
                    raise ValueError("ゾーンのカード識別にはカードのテンプレートが必要です")
            else:
                raise ValueError(f"未対応の観測領域です: {name}")

    def process(self, frame: Frame, *, deadline: float | None = None) -> GameState:
        recognition_start = time.perf_counter()
        self.stage_spans = []
        crops = self.calibration.crop_regions(frame.pixels)
        observed: dict[str, Observation] = {}
        actions: list[Action] = []
        self.cache_hits = self.recognized_regions = 0
        self.ocr_ms = 0
        for name, region in self.calibration.regions.items():
            if deadline is not None and time.monotonic() >= deadline:
                raise TimeoutError("認識・判断の期限に達しました")
            value, confidence = None, 0.0
            cached = self._cache.get(name)
            if cached is not None and np.array_equal(cached[0], crops[name]):
                _, value, confidence = cached
                self.cache_hits += 1
            elif region.kind == "number":
                ocr_started = time.perf_counter()
                maximum = 999999 if name.endswith(".lp") else 999 if name == "turn" else 60
                if isinstance(self.ocr, TesseractOCR):
                    value, confidence = self.ocr.read(crops[name], maximum, deadline=deadline)
                else:
                    value, confidence = self.ocr.read(crops[name], maximum)
                self.ocr_ms += (time.perf_counter() - ocr_started)*1000
            elif name in self.matchers:
                value, confidence = self.matchers[name].match(crops[name])
            if deadline is not None and time.monotonic() >= deadline:
                # 打ち切った認識結果をキャッシュへ保存しません。
                raise TimeoutError("認識・判断の期限に達しました")
            if cached is None or not np.array_equal(cached[0], crops[name]):
                self._cache[name] = (crops[name].copy(), value, confidence)
                self.recognized_regions += 1
            if region.kind == "action":
                if value is not None:
                    actions.append(Action(type=ActionType(value), card_id=region.card_id,
                                          target=region.target, confidence=confidence,
                                          source_region=name, observed_at=frame.captured_at))
                continue
            if name.startswith(("self.zones.", "opponent.zones.")) and value is not None:
                card = self.cards.get(str(value))
                if card is None:
                    value, confidence = None, 0
                else:
                    value = CardIdentity(card_id=card.card_id, name=card.name, card_type=card.type)
            elif name == "phase" and value is not None:
                value = Phase(value)
            elif name == "game.terminal" and value is not None:
                value = value == "ended"
            elif name == "turn_player" and value is not None:
                value = Player(value)
            elif name == "ui.animation" and value is not None:
                value = value == "playing"
            elif name == "ui.prompt" or name.startswith(("card_state.", "fact.")):
                pass
            elif value is not None:
                value = int(value)
            observed[name] = Observation(value=value, confidence=confidence, source=f"{region.kind}:{name}", observed_at=frame.captured_at)

        # 陽性のANDのみ。根拠不明・失効・矛盾から既定値を生成しません。
        proposed = {}
        for context in self.calibration.composites:
            evidence = [observed.get(name) for name in context.when]
            if not all(o is not None and o.value == label and o.confidence >= .98
                       and o.observed_at == frame.captured_at
                       for o, label in zip(evidence, context.when.values())):
                continue
            for name, value in context.emit.items():
                if name == "phase": value = Phase(value)
                elif name == "turn_player": value = Player(value)
                elif name == "ui.animation": value = value == "playing"
                elif name == "game.terminal": value = value == "ended"
                proposed.setdefault(name, []).append(Observation(value=value, confidence=min(o.confidence for o in evidence),
                    source="composite:" + context.id, observed_at=frame.captured_at))
        for name, candidates in proposed.items():
            direct = observed.get(name)
            if direct is not None and direct.value is not None:
                candidates.append(direct)
            if len({o.value for o in candidates}) != 1:
                observed[name] = Observation(source="conflicting_positive_evidence", observed_at=frame.captured_at)
            else:
                observed[name] = min(candidates, key=lambda o: o.confidence)

        def obs(name):
            return observed.get(name, Observation(observed_at=frame.captured_at))

        def player(side):
            prefix = side+".zones."
            return PlayerState(lp=obs(side+".lp"), hand_count=obs(side+".hand_count"), zones={key[len(prefix):]: value for key, value in observed.items() if key.startswith(prefix)})

        build_started = time.perf_counter()
        state_build_start = time.perf_counter()
        self.stage_spans.append({"stage": "recognition", "start": recognition_start, "end": state_build_start})
        state = GameState(sequence=frame.sequence, captured_at=frame.captured_at, media_time=frame.media_time, turn=obs("turn"), turn_player=obs("turn_player"), phase=obs("phase"), terminal=obs("game.terminal"), prompt=obs("ui.prompt"), animation=obs("ui.animation"), card_states={k.removeprefix("card_state."): v for k,v in observed.items() if k.startswith("card_state.")}, self=player("self"), opponent=player("opponent"), visible_actions=actions)
        self.state_build_ms = (time.perf_counter() - build_started)*1000
        state = state.model_copy(update={"facts": {k.removeprefix("fact."): v for k, v in observed.items() if k.startswith("fact.")}})
        self.stage_spans.append({"stage": "state_build", "start": state_build_start, "end": time.perf_counter()})
        return state
