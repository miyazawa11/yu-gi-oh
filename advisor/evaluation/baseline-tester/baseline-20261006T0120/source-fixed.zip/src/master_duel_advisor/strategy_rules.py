"""表示候補を、デッキ固有条件で絞って即時評価するローカル展開ルール。"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Literal

from pydantic import Field, model_validator

from .models import Action, ActionType, GameState, Model, Phase, Player, Recommendation
from .planning import CardRequirement, PlanBook, TurnPlanner
from .materials import valid_materials


class LogicalZoneTransition(Model):
    """実観測の空→指定カード占有と、対応配置入力を結び付ける目的。"""
    side: Literal["self"] = "self"
    zone: str = Field(pattern=r"^monster_[0-9]+$")
    card_id: str = Field(min_length=1)
    selected_card_fact: str = Field(min_length=1)
    placement_region: str = Field(pattern=r"^action\.")


class StrategyRule(Model):
    id: str
    card_id: str | None = None
    description: str
    type: ActionType
    source_region: str = Field(pattern=r"^action\.")
    target: str | None = None
    priority: int
    players: list[Player] = Field(default_factory=lambda: [Player.SELF])
    phases: list[Phase] = Field(default_factory=lambda: [Phase.MAIN1, Phase.MAIN2])
    prompt: str = "none"
    additional_prompts: list[str] = Field(default_factory=list)
    # UIの中間操作は、確認済みの直前操作と画面証拠を必要とする。
    follows: list[str] = Field(default_factory=list)
    observed_facts: dict[str, str] = Field(default_factory=dict)
    expected_prompts: list[str] = Field(default_factory=list)
    requires: list[CardRequirement] = Field(default_factory=list)
    facts: dict[str, str] = Field(default_factory=dict)
    expected_facts: dict[str, str] = Field(default_factory=dict)
    enabled: bool = True
    material_method: str | None = None
    # 計測用。操作の許可条件を変更しません。
    logical_action: str | None = None
    logical_category: str | None = None
    logical_start: bool = False
    logical_end: bool = False
    logical_count_fact: str | None = None
    logical_phase: Phase | None = None
    logical_turn_advance: bool = False
    logical_zone_transition: LogicalZoneTransition | None = None

    @model_validator(mode="after")
    def validate_logical_zone_goal(self):
        if self.logical_zone_transition is not None and (
                not self.logical_action or self.logical_count_fact is not None
                or self.logical_phase is not None or self.logical_turn_advance):
            raise ValueError("ゾーン遷移目的には目的IDが必要で、他の完了条件とは混在できません")
        return self

    def matches(self, action: Action) -> bool:
        return (action.type == self.type and action.source_region == self.source_region
                and action.card_id == self.card_id and action.target == self.target)

    def missing(self, state: GameState, threshold: float) -> list[str]:
        def known(obs, values):
            return (obs.value in values and obs.confidence >= threshold
                    and obs.observed_at == state.captured_at)
        result = []
        if not self.enabled:
            result.append("disabled")
        for name, obs, values in (("turn_player", state.turn_player, self.players),
                                  ("phase", state.phase, self.phases),
                                  ("prompt", state.prompt, [self.prompt, *self.additional_prompts])):
            if not known(obs, values):
                result.append(name)
        if not known(state.animation, [False]) or not known(state.terminal, [False]):
            result.append("active_idle")
        for requirement in self.requires:
            if not requirement.matches(state, threshold):
                result.append(f"{requirement.side}.{requirement.zone_prefix}{requirement.card_id}")
        for key, value in self.facts.items():
            if key not in state.facts or not known(state.facts[key], [value]):
                result.append(key)
        for key, value in self.observed_facts.items():
            if key not in state.facts or not known(state.facts[key], [value]):
                result.append("observed:" + key)
        if self.material_method:
            method = self.material_method
            if method == "fusion":
                target = state.facts.get("fusion.target")
                if target is None or not known(target, ["13923", "13924"]):
                    result.append("fusion.target")
                else:
                    method = "fusion_colossus" if target.value == "13923" else "fusion_titan"
            evidence = state.material_sets.get(self.material_method)
            if (evidence is None or evidence.value is None or evidence.confidence < threshold
                    or evidence.observed_at != state.captured_at
                    or not valid_materials(method, evidence.value)):
                result.append("material_set." + self.material_method)
        return result


class StrategyBook(Model):
    format: Literal["deck-strategy-v1"]
    name: str
    source: str
    rules: list[StrategyRule] = Field(min_length=1)
    min_confidence: float = Field(default=.98, gt=0, le=1)
    inference_mode: Literal["strict", "provisional"] = "strict"
    audit_profile: Literal["full_deck", "phase_transition", "normal_summon"] = "full_deck"

    @model_validator(mode="after")
    def unique_rules(self):
        if len({r.id for r in self.rules}) != len(self.rules):
            raise ValueError("展開ルールIDが重複しています")
        keys = [(r.type, r.source_region, r.card_id, r.target) for r in self.rules]
        if len(set(keys)) != len(keys):
            raise ValueError("同じ操作に複数のルールが割り当てられています")
        ids = {r.id for r in self.rules}
        if any(set(r.follows) - ids for r in self.rules):
            raise ValueError("操作の前提に未登録のルールIDがあります")
        if self.audit_profile == "phase_transition":
            if len(self.rules) != 2:
                raise ValueError("限定phase監査は2操作のみです")
            first, last = self.rules
            if not (first.type == ActionType.CHANGE_PHASE and last.type == ActionType.CONFIRM
                    and first.logical_start and not first.logical_end and last.logical_end and not last.logical_start
                    and not first.follows and first.prompt == "none" and last.prompt == "phase.select"
                    and first.expected_prompts == ["phase.select"]
                    and last.logical_phase == Phase.END and last.follows == [first.id]
                    and first.logical_action and first.logical_action == last.logical_action
                    and all(r.logical_category == "CHANGE_PHASE" and not r.material_method
                            and r.players == [Player.SELF] and r.card_id is None and not r.facts
                            and not r.requires and r.phases == [Phase.MAIN1] and r.logical_zone_transition is None
                            and len(r.observed_facts) >= 2 for r in self.rules)):
                raise ValueError("限定phase監査の対象外操作です")
        if self.audit_profile == "normal_summon":
            self.validate_normal_profile()
        return self

    def validate_normal_profile(self):
        if len(self.rules) != 3:
            raise ValueError("限定通常召喚監査は手札選択・召喚・配置の3操作のみです")
        first, summon, place = self.rules
        goal = first.logical_zone_transition
        if goal is None:
            raise ValueError("限定通常召喚には指定ゾーンの完了条件が必要です")
        occupancy = f"zone.{goal.side}.{goal.zone}.occupancy"
        common = (self.inference_mode == "strict" and self.min_confidence >= .98
                  and first.logical_action and all(
                      r.logical_action == first.logical_action and r.logical_category == "NORMAL_SUMMON"
                      and r.logical_zone_transition == goal and r.card_id == goal.card_id
                      and r.players == [Player.SELF] and r.phases == [Phase.MAIN1]
                      and r.enabled and not r.additional_prompts and not r.facts and not r.requires
                      and not r.material_method for r in self.rules))
        sequence = (first.type == ActionType.SELECT_CARD and summon.type == ActionType.NORMAL_SUMMON
                    and place.type == ActionType.CONFIRM and first.target is None and summon.target is None
                    and place.target == f"{goal.side}.{goal.zone}" and place.source_region == goal.placement_region
                    and first.logical_start and not summon.logical_start and not place.logical_start
                    and not first.logical_end and not summon.logical_end and place.logical_end
                    and not first.follows and summon.follows == [first.id] and place.follows == [summon.id]
                    and first.prompt == "none" and summon.prompt == "card.menu" and place.prompt == "placement.select"
                    and first.expected_prompts == ["card.menu"] and summon.expected_prompts == ["placement.select"]
                    and not place.expected_prompts)
        evidence = (first.observed_facts.get(occupancy) == "empty"
                    and first.observed_facts.get("normal_context.hand_layout") == "true"
                    and first.observed_facts.get("normal_context.hand_card") == goal.card_id
                    and summon.observed_facts.get(goal.selected_card_fact) == goal.card_id
                    and summon.observed_facts.get("normal_context.summon_enabled") == "true"
                    and place.observed_facts.get("normal_context.placement") == "true")
        if not (common and sequence and evidence):
            raise ValueError("限定通常召喚監査の対象外操作または陽性証拠不足です")


class RulePlanner:
    """厳密/暫定モードで条件を評価。暫定の推測は実観測とは分離する。"""
    strict = True
    recipe = None  # 従来プランナーの表示インターフェース

    def __init__(self, book: StrategyBook):
        self.book = book
        self.pending: Action | None = None
        self.last_completed: str | None = None
        self._verified_action: Action | None = None
        self.blocked: dict[str, list[str]] = {}
        self.assumptions: dict[str, list[str]] = {}
        self.inferred_used: set[str] = set()
        self.inferred_normal_used = False
        self.inferred_summon_lock = False
        self.turn_key = None
        self.reason = "盤面ごとに条件を再評価します"
        self._by_region = {r.source_region: [] for r in book.rules}
        for rule in book.rules:
            self._by_region[rule.source_region].append(rule)

    def rule_for(self, action):
        return next((r for r in self._by_region.get(action.source_region, []) if r.matches(action)), None)

    def observe(self, state):
        if state.terminal.value is True:
            self.pending = None
            self.reset()
            self._reset_inferences()
            self.turn_key = None
        elif all(o.value is not None and o.confidence >= self.book.min_confidence
                 and o.observed_at == state.captured_at for o in [state.turn, state.turn_player]):
            key = (state.turn.value, state.turn_player.value)
            if self.turn_key is not None and key != self.turn_key:
                self._reset_inferences()
                self.reset()
            self.turn_key = key

    def reset(self):
        """入力中断時にはUI手順を破棄。ターン内の使用履歴は消さない。"""
        self.pending = None
        self.last_completed = None
        self._verified_action = None

    def _reset_inferences(self):
        self.inferred_used.clear()
        self.inferred_normal_used = self.inferred_summon_lock = False

    def _infer_missing(self, rule, state, missing):
        """表示中の登録操作を根拠に未確認の展開条件だけを仮定する。観測値は書き換えない。"""
        def fresh(obs):
            return (obs is not None and obs.value is not None
                    and obs.confidence >= self.book.min_confidence and obs.observed_at == state.captured_at)
        blocked, assumed = [], []
        requirements = {f"{r.side}.{r.zone_prefix}{r.card_id}" for r in rule.requires}
        for key in missing:
            if key in rule.facts or key == "fusion.target":
                # 確認済みの不成立は楽観仮定で上書きしない。
                infer = not fresh(state.facts.get(key))
            elif key.startswith("material_set."):
                evidence = state.material_sets.get(rule.material_method)
                infer = not fresh(evidence)
                if fresh(evidence) and rule.material_method == "fusion" and not fresh(state.facts.get("fusion.target")):
                    infer = any(valid_materials(method, evidence.value) for method in ["fusion_colossus", "fusion_titan"])
            else:
                infer = key in requirements
            (assumed if infer else blocked).append(key)
        # 自分が送った操作は未使用と再推測しない。成功未確認でも重複実行を抑える。
        for key in rule.facts:
            if key in self.inferred_used:
                blocked.append("inferred_used:" + key)
        if "normal_summon.available" in rule.facts and self.inferred_normal_used:
            blocked.append("inferred_normal_summon_used")
        if "summon.allowed" in rule.facts and rule.type != ActionType.NORMAL_SUMMON and self.inferred_summon_lock:
            blocked.append("inferred_special_summon_lock")
        return blocked, assumed

    def filter_actions(self, state, actions):
        self.blocked = {}
        self.assumptions = {}
        result = []
        for action in actions:
            rule = self.rule_for(action)
            missing = rule.missing(state, self.book.min_confidence) if rule else ["unregistered_action"]
            if rule and self.book.inference_mode == "provisional":
                missing, assumed = self._infer_missing(rule, state, missing)
                if assumed:
                    self.assumptions[action.source_region] = assumed
            if rule and rule.follows and self.last_completed not in rule.follows:
                missing = missing + ["unconfirmed_predecessor"]
            if self.pending:
                missing = missing + ["pending_verification"]
            if action.confidence < self.book.min_confidence or action.observed_at != state.captured_at:
                missing = missing + ["stale_or_uncertain_action"]
            # 同一ボタンの認識が複数なら位置を勝手に選びません。
            if sum(a.source_region == action.source_region for a in actions) != 1:
                missing = missing + ["ambiguous_action"]
            if missing:
                self.blocked[action.source_region] = missing
            else:
                result.append(action)
        return result

    def decide(self, state, actions):
        allowed = self.filter_actions(state, actions) if actions else []
        if not allowed:
            return Recommendation(reason="展開条件または操作結果の確認を待っています", recognition_status="rule_blocked")
        action = min(allowed, key=lambda a: (-self.rule_for(a).priority, -a.confidence, a.source_region))
        assumed = self.assumptions.get(action.source_region, [])
        return Recommendation(action=action, target=action.target, confidence=action.confidence,
                              reason=self.rule_for(action).description + ("。暫定推測: " + ", ".join(assumed) if assumed else ""),
                              recognition_status="deck_rule_inferred" if assumed else "deck_rule")

    def issued(self, action):
        self.pending = action
        self._verified_action = None
        rule = self.rule_for(action)
        if rule and self.book.inference_mode == "provisional":
            if action.type == ActionType.ACTIVATE:
                self.inferred_used.update(k for k in rule.facts if k.startswith("unused."))
            if action.type == ActionType.SPECIAL_SUMMON:
                self.inferred_used.update(k for k in rule.facts if k.startswith("unused."))
            if action.type == ActionType.NORMAL_SUMMON:
                self.inferred_normal_used = True
            if rule.id == "verte_fusion":
                self.inferred_summon_lock = True

    def expected(self, action, state):
        self._verified_action = None
        rule = self.rule_for(action)
        valid = rule is not None and all(
            key in state.facts and state.facts[key].value == value
            and state.facts[key].confidence >= self.book.min_confidence
            and state.facts[key].observed_at == state.captured_at
            for key, value in rule.expected_facts.items())
        if valid and rule.expected_prompts:
            valid = (state.prompt.value in rule.expected_prompts
                     and state.prompt.confidence >= self.book.min_confidence
                     and state.prompt.observed_at == state.captured_at
                     and state.animation.value is False
                     and state.animation.confidence >= self.book.min_confidence
                     and state.animation.observed_at == state.captured_at
                     and state.terminal.value is False
                     and state.terminal.confidence >= self.book.min_confidence
                     and state.terminal.observed_at == state.captured_at)
        if valid and self.pending == action:
            self._verified_action = action
        return valid

    def feedback(self, status):
        if status == "changed" and self.pending is not None and self._verified_action == self.pending:
            self.last_completed = self.rule_for(self.pending).id
        else:
            self.last_completed = None
        self.pending = None
        self._verified_action = None
        self.reason = "最新盤面で再計画します。画面遷移だけで効果解決とは扱いません"

    def snapshot(self):
        return {"recipe": None, "goal": self.book.name, "step": None,
                "pending": self.pending is not None, "last_completed": self.last_completed,
                "reason": self.reason, "blocked": self.blocked,
                "inference_mode": self.book.inference_mode, "assumptions": self.assumptions,
                "inferred_used": sorted(self.inferred_used), "inferred_normal_used": self.inferred_normal_used,
                "inferred_summon_lock": self.inferred_summon_lock}


def load_planner(path: Path):
    data = json.loads(path.read_text(encoding="utf-8"))
    if data.get("format") == "deck-strategy-v1":
        return RulePlanner(StrategyBook.model_validate(data))
    return TurnPlanner(PlanBook.load(path))
