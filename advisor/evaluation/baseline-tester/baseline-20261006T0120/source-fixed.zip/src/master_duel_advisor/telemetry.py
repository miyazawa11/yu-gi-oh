"""目的達成単位の計測。入力数・模擬結果を実機成功標本に数えません。"""
from __future__ import annotations

import json
import hashlib
import platform
import math
import time
import uuid
from contextlib import contextmanager
from dataclasses import replace
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

STAGES = ("capture", "recognition", "state_build", "candidate", "decision", "coordinate", "input", "verify")
REQUIRED_CATEGORIES = ("ACTIVATE_EFFECT", "SPECIAL_SUMMON", "NORMAL_SUMMON", "SPELL_TRAP", "ATTACK", "CHANGE_PHASE")
REQUIRED_STEP_TYPES = ("ACTIVATE", "SELECT_CARD", "SELECT_TARGET", "CONFIRM", "CANCEL", "NORMAL_SUMMON",
                       "SPECIAL_SUMMON", "ATTACK", "CHANGE_PHASE", "SET")


def union_ms(spans):
    intervals = sorted((s["start"], s["end"]) for s in spans if s.get("end") is not None)
    total, end = 0.0, None
    for start, stop in intervals:
        total += max(0, stop - max(start, end if end is not None else start))
        end = max(stop, end if end is not None else stop)
    return total * 1000


class MeasuredCapture:
    def __init__(self, source, telemetry):
        self.source, self.telemetry = source, telemetry

    def read(self):
        self.telemetry.admit(self.telemetry.clock())
        with self.telemetry.span("capture") as span:
            frame = self.source.read()
        if frame is None:
            self.telemetry.event("capture_empty")
            return None
        return replace(frame, capture_start=span["start"], capture_end=span["end"])

    def close(self):
        return self.source.close()


class ActionTelemetry:
    def __init__(self, output: Path, clock=time.perf_counter, mode="unclassified", trials=None):
        if mode not in {"live_autonomous", "assisted", "synthetic", "unclassified"}:
            raise ValueError("計測モードが不正です")
        self.output, self.clock, self.mode = output, clock, mode
        self.run_id = uuid.uuid4().hex
        self.spans, self.events, self.records = [], [], []
        self.active = None
        self.current_step = None
        self.trials = list(trials or [])
        self.trials_registered_at = self.clock()
        source = Path(__file__).parent
        digest = hashlib.sha256()
        for path in sorted(source.glob("*.py")):
            digest.update(path.name.encode()); digest.update(path.read_bytes())
        self.metadata = {"run_id": self.run_id, "mode": mode, "source_sha256": digest.hexdigest(),
                         "python": platform.python_version(), "platform": platform.platform(),
                         "clock": "perf_counter", "clock_resolution_seconds": time.get_clock_info("perf_counter").resolution,
                         "registered_trials": list(self.trials)}

    def configure(self, **values):
        for name, value in values.items():
            encoded = json.dumps(value, sort_keys=True, ensure_ascii=False, default=str).encode("utf-8")
            self.metadata[name + "_sha256"] = hashlib.sha256(encoded).hexdigest()
            self.metadata[name] = value

    def admit(self, capture_start):
        if self.active is not None or not self.trials:
            return
        trial = self.trials.pop(0)
        self.active = {"schema": "logical-action-v1", "run_id": self.run_id,
                       "action_id": uuid.uuid4().hex, "mode": self.mode,
                       "started_utc": datetime.now(timezone.utc).isoformat(),
                       "admission": "scheduled_trial", "admitted_at": self.trials_registered_at,
                       "logical_action": trial["logical_action"], "category": trial["category"],
                       "classified": True, "capture_start": capture_start,
                       "count_fact": trial.get("count_fact"), "count_before": None,
                       "zone_transition": trial.get("zone_transition"),
                       "before_sequence": None, "turn_before": None, "phase_before": None,
                       "state_before": None, "steps": [], "fallback_used": False,
                       "misclick": None, "misclick_evidence": None}

    def observe(self, frame, state):
        self.admit(frame.capture_start)
        if self.active and self.active["state_before"] is None:
            self.active.update(before_sequence=state.sequence, state_before=state.model_dump(mode="json"),
                               turn_before=state.turn.model_dump(), phase_before=state.phase.model_dump(),
                               count_before=self.count(state, self.active["count_fact"]))

    @contextmanager
    def span(self, stage):
        item = {"stage": stage, "start": self.clock(), "end": None}
        self.spans.append(item)
        try:
            yield item
        except Exception as exc:
            item["error"] = type(exc).__name__
            raise
        finally:
            item["end"] = self.clock()

    def event(self, status, **values):
        if status == "fallback" and self.active is not None:
            self.active["fallback_used"] = True
        self.events.append({"at": self.clock(), "status": status, **values})

    def import_spans(self, spans):
        # 再利用した認識結果は同じ区間を二重記録しません。
        for span in spans:
            if span not in self.spans:
                self.spans.append(span)

    @staticmethod
    def count(state, key):
        observation = state.facts.get(key) if key else None
        if (observation is None or observation.confidence < .98
                or observation.observed_at != state.captured_at
                or observation.value is None):
            return None
        try:
            value = int(observation.value)
            return value if value >= 0 else None
        except (TypeError, ValueError):
            return None

    def begin_step(self, action, rule, state, frame, recommendation, capture_anchor=None):
        group = getattr(rule, "logical_action", None)
        if self.active and self.active["logical_action"] != group:
            self.finish("interrupted", "Decision failure", "別の目的へ遷移しました")
        if self.active is None:
            classified = bool(group and rule.logical_start)
            self.active = {
                "schema": "logical-action-v1", "run_id": self.run_id,
                "action_id": uuid.uuid4().hex, "mode": self.mode,
                "started_utc": datetime.now(timezone.utc).isoformat(),
                "logical_action": group, "category": getattr(rule, "logical_category", None),
                "admission": "candidate_observed", "admitted_at": self.clock(),
                "classified": classified, "capture_start": capture_anchor if capture_anchor is not None else frame.capture_start,
                "count_fact": getattr(rule, "logical_count_fact", None),
                "zone_transition": self.zone_spec(rule),
                "count_before": self.count(state, getattr(rule, "logical_count_fact", None)),
                "before_sequence": state.sequence, "turn_before": state.turn.model_dump(),
                "phase_before": state.phase.model_dump(), "state_before": state.model_dump(mode="json"),
                "steps": [], "fallback_used": False,
                "misclick": None, "misclick_evidence": None,
            }
        self.active["fallback_used"] |= recommendation.get("recognition_status", "").startswith("llm") or any(
            event["status"] == "fallback" and event["at"] >= (self.active["capture_start"] or float("inf")) for event in self.events)
        spec = self.active.get("zone_transition")
        selection = state.facts.get(spec["selected_card_fact"]) if spec else None
        step = {"step_id": uuid.uuid4().hex, "rule_id": getattr(rule, "id", None),
                "before_sequence": state.sequence,
                "selection_evidence": selection.model_dump(mode="json") if selection and self.visual(selection, state, "template:") else None,
                "action": action.model_dump(mode="json"), "misclick": None, "capture_start": frame.capture_start,
                "capture_end": frame.capture_end, "input_sent": False,
                "retry": False, "retry_candidate": any(s["input_sent"] is not False and s["action"]["source_region"] == action.source_region and s["action"]["type"] == action.type
                             and s["action"]["card_id"] == action.card_id and s["action"]["target"] == action.target for s in self.active["steps"])}
        self.active["steps"].append(step)
        self.current_step = step

    def input_result(self, sent, point):
        if self.current_step:
            self.current_step.update(input_sent=sent, screen_point=list(point),
                                     retry=sent is not False and self.current_step["retry_candidate"])

    @staticmethod
    def fresh(observation, state):
        return observation.value is not None and observation.confidence >= .98 and observation.observed_at == state.captured_at

    @staticmethod
    def zone_spec(rule):
        value = getattr(rule, "logical_zone_transition", None)
        return value.model_dump(mode="json") if value is not None else None

    @classmethod
    def visual(cls, observation, state, prefix):
        return observation is not None and cls.fresh(observation, state) and observation.source.startswith(prefix)

    def zone_confirmed(self, rule, state):
        spec = self.active.get("zone_transition")
        if not spec or spec != self.zone_spec(rule):
            return False
        from .models import GameState
        before = GameState.model_validate(self.active["state_before"])
        key = f'zone.{spec["side"]}.{spec["zone"]}.occupancy'
        empty, occupied = before.facts.get(key), state.facts.get(key)
        card = state.self.zones.get(spec["zone"])
        if not (self.visual(empty, before, "template:") and empty.value == "empty"
                and self.visual(occupied, state, "template:") and occupied.value == "occupied"
                and self.visual(card, state, "card:") and card.value.card_id == spec["card_id"]
                and state.sequence > before.sequence):
            return False
        selected = False
        placed = False
        for step in self.active["steps"]:
            evidence = step.get("selection_evidence")
            if evidence:
                selected = evidence["value"] == spec["card_id"] and step["before_sequence"] > before.sequence
                if not selected:
                    placed = False
            action = step["action"]
            if (selected and step["input_sent"] is True and action["type"] == "CONFIRM"
                    and action["source_region"] == spec["placement_region"]
                    and action["target"] == f'{spec["side"]}.{spec["zone"]}'
                    and state.sequence > step["before_sequence"]):
                placed = True
        return placed

    def goal_confirmed(self, rule, state):
        if state is None or self.active is None or self.active["state_before"] is None:
            return False
        if self.active.get("zone_transition") or getattr(rule, "logical_zone_transition", None) is not None:
            return self.zone_confirmed(rule, state)
        if getattr(rule, "logical_turn_advance", False):
            old = self.active["turn_before"]
            original = self.active["state_before"]["captured_at"]
            return (old["value"] is not None and old["confidence"] >= .98 and old["observed_at"] == original
                    and self.fresh(state.turn, state) and state.turn.value > old["value"]
                    and self.fresh(state.turn_player, state) and state.turn_player.value == "opponent")
        if getattr(rule, "logical_phase", None) is not None:
            old = self.active["phase_before"]
            original = self.active["state_before"]["captured_at"]
            return (old["value"] is not None and old["confidence"] >= .98 and old["observed_at"] == original
                    and old["value"] != rule.logical_phase and self.fresh(state.phase, state)
                    and state.phase.value == rule.logical_phase)
        before, after = self.active["count_before"], self.count(state, self.active["count_fact"])
        self.active["count_after"] = after
        return before is not None and after is not None and after > before

    def complete_step(self, status, rule, state, at=None):
        at = self.clock() if at is None else at
        if self.current_step:
            self.current_step.update(result=status, end=at, after_sequence=state.sequence if state else None)
        if status == "changed" and getattr(rule, "logical_end", False):
            self.active["state_after"] = state.model_dump(mode="json") if state else None
            if self.active["classified"] and self.goal_confirmed(rule, state):
                self.finish("success", None, None, end=at)
            else:
                self.finish("unverified", "Verification failure", "目的の新鮮な状態差分を確認できません", end=at)
        elif status in {"duel_ended", "unexpected_state", "esc", "input_blocked", "input_error_outcome_unknown"}:
            category = "Input failure" if status.startswith("input") else "Verification failure"
            self.finish("interrupted" if status == "esc" else "unverified", category, status, end=at)
        elif not getattr(rule, "logical_action", None):
            self.finish("unclassified", "Verification failure", "目的単位の開始・完了条件が未登録です", end=at)

    def finish(self, result, category, reason, end=None):
        if self.active is None:
            return
        entry, self.active = self.active, None
        end = self.clock() if end is None else end
        start = entry["capture_start"]
        spans = [{**s, "start": max(start, s["start"]), "end": min(end, s["end"])}
                 for s in self.spans if start is not None and s["end"] is not None and s["end"] >= start and s["start"] <= end]
        entry.update(result=result, failure_category=category, failure_reason=reason,
                     ended_at=end, total_ms=(end-start)*1000 if start is not None else None, spans=spans,
                     steps_count=len(entry["steps"]), input_count=sum(s["input_sent"] is True for s in entry["steps"]),
                     retry_count=sum(s["retry"] for s in entry["steps"]))
        for stage in STAGES:
            selected = [s for s in spans if s["stage"] == stage]
            entry[stage + "_start"] = start if stage == "capture" else min((s["start"] for s in selected), default=None)
            entry[stage + "_end"] = max((s["end"] for s in selected), default=None)
        entry["verify_attempt_end"] = entry["verify_end"]
        entry["verify_end"] = end if result == "success" else None
        entry["successful_e2e_ms"] = entry["total_ms"] if result == "success" else None
        # verifyはwall区間。内部のcapture/recognition等と重複加算しません。
        internal = [s for s in spans if s["stage"] != "verify"]
        entry["system_internal_ms"] = union_ms(internal)
        windows = [s for s in spans if s["stage"] == "verify"]
        waiting = union_ms(windows)
        overlaps = [{"start": max(s["start"], v["start"]), "end": min(s["end"], v["end"])}
                    for s in internal for v in windows if s["start"] < v["end"] and s["end"] > v["start"]]
        entry["input_after_verify_wall_ms"] = waiting
        entry["game_wait_estimate_ms"] = max(0, waiting-union_ms(overlaps))
        entry["wait_estimate_limitation"] = "ゲーム待機・poll待機・未計測Python処理の残差。通信/演出の真因は未計測"
        entry["unattributed_ms"] = max(0, entry["total_ms"]-entry["system_internal_ms"]-entry["game_wait_estimate_ms"]) if start is not None else None
        entry["clock_domain"] = "python_perf_counter_seconds"
        entry["stage_ms"] = {stage: union_ms([s for s in spans if s["stage"] == stage]) for stage in STAGES}
        entry["measurement_complete"] = start is not None and all(entry[s+"_start"] is not None for s in STAGES)
        self.records.append(entry)
        self.output.mkdir(parents=True, exist_ok=True)
        with (self.output / "logical-actions.jsonl").open("a", encoding="utf-8") as log:
            log.write(json.dumps(entry, ensure_ascii=False, allow_nan=False) + "\n")
        self.current_step = None

    def close(self, reason):
        failures = [span for span in self.spans if span.get("error")]
        categories = {"capture": "Recognition failure", "recognition": "Recognition failure", "state_build": "State failure",
                      "decision": "Decision failure", "candidate": "Decision failure", "coordinate": "Coordinate failure", "input": "Input failure"}
        category = categories.get(failures[-1]["stage"], "Verification failure") if failures else "Verification failure"
        classified_events = [event for event in self.events if event.get("failure_category")
                             and self.active and event["at"] >= (self.active["capture_start"] or 0)]
        if classified_events:
            category = classified_events[-1]["failure_category"]
        self.finish("interrupted", category, reason)
        self.output.mkdir(parents=True, exist_ok=True)
        (self.output / "run-metadata.json").write_text(json.dumps(self.metadata, indent=2, ensure_ascii=False, default=str) + "\n", encoding="utf-8")
        (self.output / "logical-actions.jsonl").touch(exist_ok=True)
        with (self.output / "telemetry-spans.jsonl").open("a", encoding="utf-8") as log:
            for span in self.spans:
                log.write(json.dumps({"run_id": self.run_id, "mode": self.mode, **span}, ensure_ascii=False) + "\n")
        with (self.output / "telemetry-events.jsonl").open("a", encoding="utf-8") as log:
            for event in self.events:
                log.write(json.dumps({"run_id": self.run_id, "mode": self.mode, **event}, ensure_ascii=False) + "\n")


def summarize(paths, required_categories=REQUIRED_CATEGORIES, reviews=None, required_step_types=REQUIRED_STEP_TYPES):
    rows = []
    for path in paths:
        for number, line in enumerate(Path(path).read_text(encoding="utf-8").splitlines(), 1):
            if not line.strip():
                continue
            value = json.loads(line)
            if value.get("schema") != "logical-action-v1":
                raise ValueError(f"目的単位ログではありません: {path}:{number}")
            rows.append(value)
    ids = [r["action_id"] for r in rows]
    if len(ids) != len(set(ids)):
        raise ValueError("重複action_idを合算できません")
    review_map = {}
    if reviews:
        for path in reviews:
            for line in Path(path).read_text(encoding="utf-8").splitlines():
                if not line.strip():
                    continue
                review = json.loads(line)
                if (not isinstance(review.get("misclick"), bool) or not review.get("evidence")
                        or not review.get("reviewer") or review.get("step_id") in review_map):
                    raise ValueError("誤クリックレビューの証拠/担当/一意step_idが必要です")
                review_map[review["step_id"]] = review
    known_step_ids = {s["step_id"] for r in rows for s in r["steps"]}
    if set(review_map) - known_step_ids:
        raise ValueError("レビューが存在しない子入力を参照しています")
    live = [r for r in rows if r["mode"] == "live_autonomous"]
    valid = [r for r in live if isinstance(r.get("total_ms"), (float, int)) and math.isfinite(r["total_ms"]) and r["total_ms"] >= 0]
    values = [r["total_ms"] for r in valid]
    n = len(live)
    success = sum(r["result"] == "success" for r in live)
    clicks = sum(r["input_count"] for r in live)
    input_steps = [s for r in live for s in r["steps"] if s["input_sent"] is not False]
    reviewed = [review_map[s["step_id"]] for s in input_steps if s["step_id"] in review_map]
    review_complete = bool(input_steps) and len(reviewed) == len(input_steps)
    misclick_rate = sum(r["misclick"] for r in reviewed)/len(input_steps) if review_complete else None
    categories = sorted({r.get("category") for r in live if r.get("category")})
    step_types = sorted({s.get("action", {}).get("type") for s in input_steps if s.get("action", {}).get("type")})
    stats = {"average_ms": float(np.mean(values)) if values else None,
             **{f"p{p}_ms": float(np.percentile(values, p)) if values else None for p in (50, 90, 95)},
             "max_ms": max(values, default=None)}
    successful_values = [r["total_ms"] for r in valid if r["result"] == "success"]
    successful_stats = {"samples": len(successful_values), "average_ms": float(np.mean(successful_values)) if successful_values else None,
                        **{f"p{p}_ms": float(np.percentile(successful_values, p)) if successful_values else None for p in (50, 90, 95)},
                        "max_ms": max(successful_values, default=None)}
    gates = {"samples": n >= 100, "timings_complete": bool(n) and len(valid) == n and all(r["measurement_complete"] for r in live),
             "classification_complete": bool(n) and all(r["classified"] for r in live),
             "pre_admitted_trials": bool(n) and all(r.get("admission") == "scheduled_trial" for r in live),
             "coverage": set(required_categories) <= set(categories),
             "step_coverage": set(required_step_types) <= set(step_types),
             "average": bool(values) and stats["average_ms"] <= 3000 and bool(successful_values) and successful_stats["average_ms"] <= 3000,
             "p50": bool(values) and stats["p50_ms"] <= 2500 and bool(successful_values) and successful_stats["p50_ms"] <= 2500,
             "p95": bool(values) and stats["p95_ms"] <= 5000 and bool(successful_values) and successful_stats["p95_ms"] <= 5000,
             "success": bool(n) and success/n >= .99,
             "misclick_review_complete": review_complete,
             "misclick": misclick_rate is not None and misclick_rate <= .005}
    return {"schema": "logical-benchmark-v1", "samples": n, "all_records": len(rows),
            "excluded_modes": {mode: sum(r["mode"] == mode for r in rows) for mode in sorted({r["mode"] for r in rows}) if mode != "live_autonomous"},
            **stats, "success_rate": success/n if n else None,
            "misoperation_rate": sum(any(review_map[s["step_id"]]["misclick"] for s in r["steps"] if s["input_sent"] is not False) for r in live)/n if n and review_complete else None,
            "misclick_rate": misclick_rate, "misclick_rate_note": "子入力数を分母とする独立レビュー。未レビューは0件扱いにしない",
            "input_count": clicks, "retry_rate": sum(r["retry_count"] > 0 for r in live)/n if n else None,
            "fallback_rate": sum(r["fallback_used"] for r in live)/n if n else None,
            "observed_categories": categories, "required_categories": list(required_categories),
            "observed_step_types": step_types, "required_step_types": list(required_step_types),
            "stage_average_ms": {stage: float(np.mean([r["stage_ms"][stage] for r in live if stage in r.get("stage_ms", {})]))
                                 if any(stage in r.get("stage_ms", {}) for r in live) else None for stage in STAGES},
            "gates": gates, "passed": all(gates.values()),
            "successful_e2e_ms": successful_stats, "all_attempt_elapsed_ms": stats,
            "failure_cases": [{"action_id": r["action_id"], "result": r["result"], "reason": r["failure_reason"]} for r in live if r["result"] != "success"],
            "limitations": ["成功例だけを平均から除外しない。欠測があればKPI不合格", "目的分類の網羅は必要条件。試験シナリオの代表性は別途レビューが必要"]}


def load_trials(path, planner):
    """capture前に予定目的を登録。操作/推薦の順序は変更しません。"""
    ids = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(ids, list) or not ids or any(not isinstance(key, str) for key in ids):
        raise ValueError("試験予定は目的IDの非空JSON配列で指定してください")
    rules = getattr(getattr(planner, "book", None), "rules", [])
    starts = {rule.logical_action: rule for rule in rules if rule.logical_start}
    if set(ids) - set(starts):
        raise ValueError("試験予定に開始条件未登録の目的IDがあります")
    return [{"logical_action": key, "category": starts[key].logical_category,
             "count_fact": starts[key].logical_count_fact,
             "zone_transition": ActionTelemetry.zone_spec(starts[key])} for key in ids]
