"""promptの意味を設定したUIルールだけを優先実行します。"""
from pathlib import Path

from pydantic import Field

from .models import Action, ActionType, GameState, Model, Recommendation


class UiRule(Model):
    prompt: str = Field(min_length=1)
    type: ActionType
    source_region: str = Field(pattern=r"^action\.")
    card_id: str | None = None
    target: str | None = None


class UiPolicy(Model):
    rules: list[UiRule] = Field(default_factory=list)
    min_confidence: float = Field(default=.98, gt=0, le=1)

    @classmethod
    def load(cls, path: Path):
        return cls.model_validate_json(path.read_text(encoding="utf-8"))

    def decide(self, state: GameState, actions: tuple[Action, ...]) -> Recommendation | None:
        if state.prompt.value in {None, "none"}:
            return None
        choices = [a for a in actions if any(
            r.prompt == state.prompt.value and r.type == a.type and r.source_region == a.source_region
            and (r.card_id is None or r.card_id == a.card_id)
            and (r.target is None or r.target == a.target) for r in self.rules)]
        if (len(choices) != 1 or state.prompt.confidence < self.min_confidence
                or state.prompt.observed_at != state.captured_at
                or choices[0].confidence < self.min_confidence):
            return Recommendation(reason="確認UIの意味または対象を一意に確認できません", recognition_status="abstained")
        a = choices[0]
        return Recommendation(action=a, target=a.target, confidence=min(a.confidence, state.prompt.confidence),
                              reason=f"登録した確認UIルール: {state.prompt.value}", recognition_status="ui_rule")
