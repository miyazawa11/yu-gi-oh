"""明示的な上限と観測確認を持つ反復型 UI Agent Loop。"""
from __future__ import annotations

import hashlib
import json
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Protocol

import numpy as np

from .capture import Frame, LiveCaptureSource
from .image_io import write_image
from .models import Action, GameState
from .pipeline import FrameGate, Pipeline, save_json
from .perception import Perception
from .telemetry import ActionTelemetry, MeasuredCapture
from .safety import ControlState, DesktopControl, GuardedClicker, InputBlocked, WindowsDesktop


class Capture(Protocol):
    def read(self) -> Frame | None: ...
    def close(self) -> None: ...


class Clicker(Protocol):
    def click(self, x: int, y: int) -> None: ...


class StopSignal(Protocol):
    def stopped(self) -> bool: ...


@dataclass(frozen=True)
class LoopLimits:
    max_seconds: float = 300
    max_actions: int = 100
    min_confidence: float = 0.98
    max_retries: int = 1
    max_same_action: int = 3
    settle_seconds: float = 0
    verify_seconds: float = 3
    verify_poll_seconds: float = 0.05
    min_image_change: float = 0.005
    max_observation_age: float = 1.0

    def __post_init__(self):
        if self.max_seconds <= 0 or self.max_actions <= 0 or not 0 < self.min_confidence <= 1:
            raise ValueError("実行時間・操作回数は正、信頼度は0〜1で指定してください")
        if self.max_retries < 0 or self.max_same_action < 1 or self.verify_seconds <= 0:
            raise ValueError("再試行・繰り返し・確認の上限が不正です")
        if (self.settle_seconds < 0 or self.verify_poll_seconds <= 0
                or self.max_observation_age <= 0 or not 0 <= self.min_image_change <= 1
                or not all(np.isfinite(v) for v in [self.max_seconds, self.settle_seconds,
                           self.verify_seconds, self.verify_poll_seconds, self.max_observation_age])):
            raise ValueError("待機・確認周期・観測期限は有限の適切な値で指定してください")


class Recovery:
    """失敗後は最新画面から再認識し、古い座標を再利用しません。"""
    def next_frame(self, capture: Capture) -> Frame | None:
        return capture.read()


class Verification:
    def __init__(self, limits: LoopLimits):
        self.limits = limits

    def changed(self, before: np.ndarray, after: np.ndarray) -> bool:
        if before.shape != after.shape:
            return True
        a = before.astype(np.float32) / 255
        b = after.astype(np.float32) / 255
        return float(np.mean(np.abs(a - b))) >= self.limits.min_image_change

    def expected(self, before_image: np.ndarray, after_image: np.ndarray,
                 before_state: GameState, after_state: GameState, action: Action) -> bool:
        """画素だけの演出変化で成功とせず、認識状態または候補 UI の変化を求めます。"""
        if not self.changed(before_image, after_image):
            return False
        def value(observation):
            return observation.value
        fields = [(before_state.turn, after_state.turn),
                  (before_state.prompt, after_state.prompt),
                  (before_state.phase, after_state.phase),
                  (before_state.turn_player, after_state.turn_player),
                  (before_state.self.lp, after_state.self.lp),
                  (before_state.opponent.lp, after_state.opponent.lp),
                  (before_state.self.hand_count, after_state.self.hand_count)]
        if any(value(a) is not None and value(b) is not None and value(a) != value(b)
               and min(a.confidence,b.confidence) >= self.limits.min_confidence
               and b.observed_at == after_state.captured_at
               for a,b in fields):
            return True
        # 選択済み枚数や対象だけが変わり、promptとボタンが同じ場合も確認する。
        if any(before_state.facts[key].value is not None and after_state.facts[key].value is not None
               and before_state.facts[key].value != after_state.facts[key].value
               and min(before_state.facts[key].confidence, after_state.facts[key].confidence) >= self.limits.min_confidence
               and after_state.facts[key].observed_at == after_state.captured_at
               for key in before_state.facts.keys() & after_state.facts.keys()):
            return True
        for side in ["self", "opponent"]:
            old, new = getattr(before_state, side).zones, getattr(after_state, side).zones
            if any(old[name].value != new[name].value and old[name].value is not None
                   and new[name].value is not None
                   and min(old[name].confidence,new[name].confidence) >= self.limits.min_confidence
                   and new[name].observed_at == after_state.captured_at
                   for name in old.keys() & new.keys()):
                return True
        before_actions = {(a.type, a.source_region, a.card_id, a.target) for a in before_state.visible_actions}
        after_actions = {(a.type, a.source_region, a.card_id, a.target) for a in after_state.visible_actions
                         if a.confidence >= self.limits.min_confidence and a.observed_at == after_state.captured_at}
        # 認識喪失や演出中の空候補だけでは次の手順へ進めません。
        return bool(after_actions) and before_actions != after_actions


class AgentLoop:
    def __init__(self, capture: Capture, pipeline: Pipeline, calibration, clicker: Clicker,
                 stop_signal: StopSignal, output: Path, screen_rect: tuple[int,int,int,int],
                 limits: LoopLimits = LoopLimits(), recovery: Recovery | None = None,
                 verification: Verification | None = None, clock=time.monotonic,
                 sleep=time.sleep, telemetry_mode="unclassified", benchmark_trials=None):
        self.telemetry = ActionTelemetry(output, mode=telemetry_mode, trials=benchmark_trials)
        self.telemetry.configure(calibration=calibration.model_dump(mode="json"),
                                 template_assets=getattr(pipeline.perception, "asset_hashes", {}),
                                 stable_features=getattr(pipeline.perception, "stable_statistics", {}),
                                 strategy=getattr(getattr(pipeline, "planner", None), "book", None).model_dump(mode="json")
                                 if getattr(getattr(pipeline, "planner", None), "book", None) else None,
                                 limits=asdict(limits), capture={"type": type(capture).__name__, "rect": screen_rect})
        self.capture, self.pipeline, self.calibration = MeasuredCapture(capture, self.telemetry), pipeline, calibration
        self.clicker, self.stop_signal, self.output = clicker, stop_signal, output
        self.screen_rect, self.limits = screen_rect, limits
        self.recovery, self.verification = recovery or Recovery(), verification or Verification(limits)
        self.clock, self.sleep = clock, sleep
        self.repeat_key = None
        self.repeat_count = 0
        self.completed = 0
        self.deadline = None
        self.gate = FrameGate(calibration=calibration, refresh_seconds=.5)
        self.pending_frame = None
        self.pending_state = None
        self.decision_frame = None
        self.decision_state = None
        self.decision_capture_start = None
        self.latencies: list[float] = []
        self.control_state = ControlState.OBSERVING

    def _coordinates(self, action: Action, image_shape) -> tuple[int,int]:
        region = self.calibration.regions.get(action.source_region)
        if region is None or region.kind != "action":
            raise ValueError("候補に対応する校正済み action 領域がありません")
        h, w = image_shape[:2]
        view = self.calibration.viewport
        x = (view.x + region.rect.x * view.width + region.rect.width * view.width / 2) * w
        y = (view.y + region.rect.y * view.height + region.rect.height * view.height / 2) * h
        return self.screen_rect[0] + round(x), self.screen_rect[1] + round(y)

    def _save_frame(self, frame: Frame, name: str) -> str:
        path = self.output / "screenshots" / name
        path.parent.mkdir(parents=True, exist_ok=True)
        if not write_image(path, frame.pixels):
            raise OSError(f"スクリーンショットを書き込めません: {path}")
        return str(path)

    def _record(self, log, entry):
        self.telemetry.event(entry.get("status", "step"), reason=entry.get("reason"))
        log.write(json.dumps(entry, ensure_ascii=False, allow_nan=False) + "\n")
        log.flush()

    def _verify(self, before: Frame, initial_state: GameState) -> tuple[Frame | None, GameState | None, str]:
        deadline = self.clock() + self.limits.verify_seconds
        if self.deadline is not None:
            deadline = min(deadline, self.deadline)
        unexpected = None
        while self.clock() < deadline:
            if self.stop_signal.stopped():
                return None, None, "esc"
            if hasattr(self.stop_signal, "ready") and not self.stop_signal.ready():
                return None, None, "input_blocked"
            self.sleep(self.limits.verify_poll_seconds)
            if self.stop_signal.stopped():
                return None, None, "esc"
            after = self.capture.read()
            if after is None:
                continue
            try:
                recognition_start = self.telemetry.clock()
                if isinstance(self.pipeline.perception, Perception):
                    state = self.pipeline.perception.process(after, deadline=deadline)
                else:
                    state = self.pipeline.perception.process(after)
                spans = getattr(self.pipeline.perception, "stage_spans", None)
                self.telemetry.import_spans(spans or [{"stage": "recognition", "start": recognition_start, "end": self.telemetry.clock()}])
            except TimeoutError:
                self.telemetry.import_spans([{"stage": "recognition", "start": recognition_start, "end": self.telemetry.clock(), "error": "TimeoutError"}])
                self.telemetry.event("recognition_timeout", failure_category="Recognition failure")
                break
            except Exception:
                self.telemetry.import_spans([{"stage": "recognition", "start": recognition_start, "end": self.telemetry.clock(), "error": "RecognitionError"}])
                raise
            if state.terminal.value is True and state.terminal.confidence >= self.limits.min_confidence:
                return after, state, "duel_ended"
            planner = getattr(self.pipeline, "planner", None)
            rule = planner.rule_for(self.current_action) if hasattr(planner, "rule_for") else None
            logical_result = (getattr(rule, "logical_end", False) and self.telemetry.active is not None
                              and self.telemetry.goal_confirmed(rule, state)
                              and self.verification.changed(before.pixels, after.pixels))
            if state.sequence != initial_state.sequence and (logical_result or self.verification.expected(
                    before.pixels, after.pixels, initial_state, state, self.current_action)):
                if planner and not planner.expected(self.current_action, state):
                    unexpected = (after, state)
                    continue
                if getattr(rule, "logical_end", False) and self.telemetry.active is not None:
                    if not self.telemetry.goal_confirmed(rule, state):
                        unexpected = (after, state)
                        continue
                return after, state, "changed"
        if unexpected:
            return *unexpected, "unexpected_state"
        return None, None, "unchanged"

    def run(self) -> dict:
        self.output.mkdir(parents=True, exist_ok=True)
        started = self.clock()
        self.deadline = started + self.limits.max_seconds
        status = "running"
        log_path = self.output / "actions.jsonl"
        blocked = False
        try:
            with log_path.open("a", encoding="utf-8") as log:
                while status == "running":
                    if self.stop_signal.stopped():
                        status = "esc"
                        break
                    if self.clock() - started >= self.limits.max_seconds:
                        status = "time_limit"
                        break
                    if self.completed >= self.limits.max_actions:
                        status = "action_limit"
                        break
                    if hasattr(self.stop_signal, "ready") and not self.stop_signal.ready():
                        self.control_state = self.stop_signal.state
                        if not blocked:
                            self._record(log, {"at": self.clock(), "status": "input_blocked", "control": self.control_state})
                        blocked = True
                        self.pending_frame = None
                        self.pending_state = None
                        self.decision_frame = self.decision_state = None
                        self.decision_capture_start = None
                        self.telemetry.finish("interrupted", "Input failure", "input_blocked")
                        if isinstance(self.pipeline, Pipeline):
                            self.pipeline.decision_started = None
                            if self.pipeline.strategy_fallback:
                                self.pipeline.strategy_fallback.discard()
                        self.sleep(self.limits.verify_poll_seconds)
                        continue
                    if blocked:
                        # 再開時には以前の画面・プランをそのまま実行しません。
                        self.gate.previous = None
                        if getattr(self.pipeline, "planner", None):
                            self.pipeline.planner.reset()
                        blocked = False
                    self.control_state = ControlState.OBSERVING
                    before = self.pending_frame
                    observed_state = self.pending_state
                    decision_due = bool(getattr(self.pipeline, "decision_due", False))
                    if decision_due and self.decision_frame is not None:
                        before, observed_state = self.decision_frame, self.decision_state
                    self.pending_frame = None
                    self.pending_state = None
                    capture_read_ms = 0.0
                    if before is None or self.clock() - before.captured_at > self.limits.max_observation_age:
                        capture_started = time.perf_counter()
                        before = self.recovery.next_frame(self.capture)
                        observed_state = None
                        capture_read_ms = (time.perf_counter()-capture_started)*1000
                    if before is None:
                        self.sleep(self.limits.verify_poll_seconds)
                        continue
                    # 非同期判断の完了も処理の契機にし、静止画面の更新期限を待ちません。
                    strategy = getattr(self.pipeline, "strategy_fallback", None)
                    future = getattr(strategy, "future", None)
                    decision_ready = future is not None and future.done()
                    if not self.gate.accept(before) and not decision_ready and not decision_due:
                        self.sleep(self.limits.verify_poll_seconds)
                        continue
                    if self.decision_capture_start is None:
                        self.decision_capture_start = before.capture_start
                    if observed_state is not None and isinstance(self.pipeline, Pipeline):
                        result = self.pipeline.process(before, capture_read_ms=capture_read_ms,
                                                       observed_state=observed_state)
                    else:
                        result = self.pipeline.process(before, capture_read_ms=capture_read_ms)
                    self.telemetry.import_spans(result.get("stage_spans", []))
                    if result.get("error"):
                        self.telemetry.event("recognition_error", failure_category="Recognition failure", reason=result["error"])
                    state = GameState.model_validate(result["state"])
                    self.telemetry.observe(before, state)
                    self.decision_frame, self.decision_state = before, state
                    if state.terminal.value is True and state.terminal.confidence >= self.limits.min_confidence:
                        status = "duel_ended"
                        break
                    rec = result["recommendation"]
                    action_data = rec.get("action")
                    if rec.get("recognition_status", "").startswith("llm"):
                        self.telemetry.event("fallback")
                    elif not action_data:
                        self.decision_capture_start = None
                    if not action_data or rec.get("confidence", 0) < self.limits.min_confidence:
                        self._record(log, {"at": self.clock(), "status": "abstain", "reason": rec.get("reason"), "confidence": rec.get("confidence", 0)})
                        self.sleep(self.limits.verify_poll_seconds)
                        continue
                    action = Action.model_validate(action_data)
                    if action.confidence < self.limits.min_confidence or action.observed_at != before.captured_at:
                        self._record(log, {"at": self.clock(), "status": "abstain", "reason": "信頼度不足または候補が古い"})
                        continue
                    rule = self.pipeline.planner.rule_for(action) if hasattr(getattr(self.pipeline, "planner", None), "rule_for") else None
                    self.telemetry.begin_step(action, rule, state, before, rec, self.decision_capture_start)
                    self.decision_capture_start = None
                    with self.telemetry.span("coordinate"):
                        x, y = self._coordinates(action, before.pixels.shape)
                    self.current_action = action
                    fingerprint = hashlib.sha256(f"{action.type}:{x}:{y}".encode()).hexdigest()
                    if fingerprint == self.repeat_key:
                        self.repeat_count += 1
                    else:
                        self.repeat_key, self.repeat_count = fingerprint, 1
                    if self.repeat_count > self.limits.max_same_action:
                        status = "repeated_action"
                        self._record(log, {"at": self.clock(), "status": status, "action": action.model_dump(mode="json")})
                        break
                    self.sleep(self.limits.settle_seconds)
                    if self.stop_signal.stopped():
                        status = "esc"
                        break
                    if self.clock() >= self.deadline:
                        status = "time_limit"
                        break
                    if self.limits.settle_seconds:
                        # 待機中にダイアログや配置が変わり得るため再観測します。
                        capture_started = time.perf_counter()
                        fresh = self.capture.read()
                        capture_read_ms = (time.perf_counter()-capture_started)*1000
                        if fresh is None:
                            continue
                        fresh_result = self.pipeline.process(fresh, capture_read_ms=capture_read_ms)
                        self.telemetry.import_spans(fresh_result.get("stage_spans", []))
                        fresh_state = GameState.model_validate(fresh_result["state"])
                        if fresh_state.terminal.value is True and fresh_state.terminal.confidence >= self.limits.min_confidence:
                            status = "duel_ended"
                            break
                        fresh_rec = fresh_result["recommendation"]
                        candidates = ([Action.model_validate(fresh_rec["action"])]
                                      if fresh_rec.get("action") and fresh_rec.get("confidence", 0) >= self.limits.min_confidence
                                      else [])
                        matches = [a for a in candidates if (a.type, a.source_region, a.card_id, a.target)
                                   == (action.type, action.source_region, action.card_id, action.target)
                                   and a.confidence >= self.limits.min_confidence]
                        if len(matches) != 1:
                            self.pending_frame = fresh
                            continue
                        before, state, action = fresh, fresh_state, matches[0]
                        result = fresh_result
                        self.current_action = action
                        with self.telemetry.span("coordinate"):
                            x, y = self._coordinates(action, before.pixels.shape)
                    if not 0 <= self.clock() - before.captured_at <= self.limits.max_observation_age:
                        continue
                    self._save_frame(before, f"before-{self.completed:04d}.png")
                    if self.stop_signal.stopped() or self.clock() >= self.deadline:
                        status = "esc" if self.stop_signal.stopped() else "time_limit"
                        break
                    if self.clock() - before.captured_at > self.limits.max_observation_age:
                        continue
                    action_started = self.clock()
                    input_started = time.perf_counter()
                    self.gate.previous = None
                    if hasattr(self.pipeline, "action_issued"):
                        self.pipeline.action_issued(action)
                    try:
                        with self.telemetry.span("input"):
                            self.clicker.click(x, y)
                        self.telemetry.input_result(True, (x, y))
                    except InputBlocked as exc:
                        self.telemetry.input_result(False, (x, y))
                        self.telemetry.complete_step("input_blocked", rule, None)
                        if hasattr(self.pipeline, "action_feedback"):
                            self.pipeline.action_feedback("input_blocked")
                        self._record(log, {"at": self.clock(), "status": "input_blocked", "reason": str(exc)})
                        blocked = True
                        self.sleep(self.limits.verify_poll_seconds)
                        continue
                    except Exception as exc:
                        self.telemetry.input_result(None, (x, y))
                        self.telemetry.complete_step("input_error_outcome_unknown", rule, None)
                        if hasattr(self.pipeline, "action_feedback"):
                            self.pipeline.action_feedback("input_error_outcome_unknown")
                        self.completed += 1
                        self._record(log, {"index": self.completed, "at": action_started,
                                           "status": "input_error_outcome_unknown", "error": str(exc),
                                           "action": action.model_dump(mode="json"), "screen_point": [x,y]})
                        continue
                    action_ms = (time.perf_counter() - input_started) * 1000
                    self.control_state = ControlState.VERIFYING
                    verify_started = time.perf_counter()
                    with self.telemetry.span("verify") as verification_span:
                        after, new_state, verification = self._verify(before, state)
                    self.telemetry.complete_step(verification, rule, new_state, at=verification_span["end"])
                    verification_ms = (time.perf_counter() - verify_started) * 1000
                    if hasattr(self.pipeline, "action_feedback"):
                        self.pipeline.action_feedback(verification)
                    self.pending_frame = after
                    self.pending_state = new_state
                    latency = (action_started - before.captured_at) * 1000
                    self.latencies.append(latency)
                    self.completed += 1
                    entry = {"index": self.completed, "at": action_started, "status": verification,
                             "action": action.model_dump(mode="json"), "screen_point": [x,y],
                             "before": str(self.output / "screenshots" / f"before-{self.completed-1:04d}.png"),
                             "after": self._save_frame(after, f"after-{self.completed:04d}.png") if after is not None else None,
                             "before_sequence": state.sequence, "after_sequence": new_state.sequence if new_state else None,
                             "retries": self.repeat_count - 1,
                             "observation_to_click_ms": latency,
                             "state_before": state.model_dump(mode="json"),
                             "state_after": new_state.model_dump(mode="json") if new_state else None,
                             "metrics": {**result.get("metrics", {}), "action_ms": action_ms,
                                         "verification_ms": verification_ms,
                                         "operation_ms": (time.perf_counter() - input_started)*1000},
                             "plan": self.pipeline.planner.snapshot() if getattr(self.pipeline, "planner", None) else None}
                    self._record(log, entry)
                    if verification == "esc":
                        status = "esc"
                    elif verification == "duel_ended":
                        status = "duel_ended"
                    elif verification == "unchanged":
                        # 次周回は必ず新しい画面から認識し、古いクリック点を使わない。
                        if self.repeat_count > self.limits.max_retries:
                            status = "verification_failed"
                    elif verification == "input_blocked":
                        blocked = True
                    elif verification == "unexpected_state":
                        status = "unexpected_state"
                    else:
                        self.repeat_count = 0
        except Exception as exc:
            self.telemetry.event("loop_error", error=type(exc).__name__, reason=str(exc))
            status = "loop_error"
            raise
        finally:
            self.telemetry.close(status)
            self.capture.close()
            self.control_state = ControlState.STOPPED
        summary = {"status": status, "actions": self.completed, "elapsed_seconds": self.clock() - started,
                   "action_log": str(log_path), "screenshots": str(self.output / "screenshots"),
                   "logical_actions": len(self.telemetry.records), "logical_action_log": str(self.output / "logical-actions.jsonl"),
                   "telemetry_mode": self.telemetry.mode,
                   "observation_to_click_ms_p95": float(np.percentile(self.latencies, 95)) if self.latencies else None}
        save_json(self.output / "agent-run.json", summary)
        return summary


def make_live_loop(pipeline, rect, output, fps, limits, window_title="masterduel", benchmark_trials=None):
    desktop = WindowsDesktop()
    control = DesktopControl(desktop, desktop.find(window_title), rect)
    capture = LiveCaptureSource("mss", rect, fps)
    return AgentLoop(capture, pipeline, pipeline.perception.calibration, GuardedClicker(control),
                     control, output, rect, limits, telemetry_mode="live_autonomous", benchmark_trials=benchmark_trials)
